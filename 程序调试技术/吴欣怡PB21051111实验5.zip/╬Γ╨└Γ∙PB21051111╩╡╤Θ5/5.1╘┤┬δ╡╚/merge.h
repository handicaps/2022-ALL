#include <stdio.h>
void merge();