#include "merge.h"
void merge(int row1[],int row2[],int num1,int num2)
{
    int j=0,row3[40]={0},i=0,k=num1+num2,p=0;
    for (j = 0;j < num1;j++)
        row3[j] = row1[j];
    for (j = num1;j < k;j++)
        row3[j] = row2[j - num1];
    for (i = 0;i<k - 1;i++)
        for(j=0;j<k-1-i;j++)
            if (row3[j+1] < row3[j])
            {
                p = row3[j];
                row3[j] = row3[j+1];
                row3[j+1] = p;
            }//冒泡排序
    for (i = 0;i < k - 1;i++)
        for (j = i+1;j < k;j++)
            if ((row3[j] % row3[i]) == 0)
            {
                for (p = j;p < k;p++)
                {
                    row3[p] = row3[p + 1];
                }
                j--;
                k--;
            }//删去重复数据
    for (i = 0;i < k;i++)
        printf("%d ", row3[i]);//打印输出
        printf("\n");

}
