#include"stdio.h"
#include"XOR.h"
int main()
{
    int num1 = 0, num2 = 0, num3 = 0;
    int m = 0;
    char c;
    int row1[20] = { 0 }, row2[20] = { 0 };//row1,row2分别储存输入的两组数据
    scanf("%d", &num1);
    if (num1 > 20 || num1 < 1)
    {
        printf("Wrong Input!");
        return 1;
    }
    for (m = 0;m < num1;m++)
    {
        scanf("%d", &row1[m]);
        c = getchar();
        if (c == '\n')
            break;
        if ((c != ' ') && (c != '\n'))
        {
            printf("Wrong Input!");
            return 1;
        }

    }
    scanf("%d", &num2);
    if (num2 > 20 || num2 < 1)
    {
        printf("Wrong Input!");
        return 1;
    }
    for (m = 0;m < num2;m++)
    {
        scanf("%d", &row2[m]);
        c = getchar();
        if (c == '\n')
            break;
    }
    XOR(row1, row2, num1, num2);
}
