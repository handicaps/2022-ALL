#include"stdio.h"
void XOR(int row1[], int row2[], int num1, int num2)
{
    int j = 0, row3[40] = { 0 }, i = 0,p = 0;
    for (i = 0;i < num1-1;i++)
        for (j = i + 1;j < num1;j++)
            if ((row1[j] - row1[i] == 0))
            {
                for (p = j;p < num1;p++)
                {
                    row3[p] = row3[p + 1];
                }
                j--;
                num1--;
            }//删去重复数据
    for (i = 0;i < num2 - 1;i++)
        for (j = i + 1;j < num2;j++)
            if ((row2[j] - row2[i] == 0))
            {
                for (p = j;p < num2;p++)
                {
                    row2[p] = row2[p + 1];
                }
                j--;
                num2--;
            }//删去重复数据
    for(i=0;i<num1;i++)
        for(j=0;j<num2;j++)
            if (row1[i] == row2[j])
            {
                for (p = i;p < num1;p++)
                {
                    row1[p] = row1[p + 1];           
                }
                i--;
                num1--;
                for (p = j;p < num2;p++)
                    row2[p] = row2[p + 1];
                j--;
                num2--;
            }
    int k = num1 + num2;
    for (j = 0;j < num1;j++)
        row3[j] = row1[j];
    for (j = num1;j < k;j++)
        row3[j] = row2[j - num1];
    for (i = 0;i < k - 1;i++)
        for (j = 0;j < k - 1 - i;j++)
            if (row3[j + 1] > row3[j])
            {
                p = row3[j];
                row3[j] = row3[j + 1];
                row3[j + 1] = p;
            }//冒泡排序
    for (i = 0;i < k;i++)
        printf("%d ", row3[i]);//打印输出
}