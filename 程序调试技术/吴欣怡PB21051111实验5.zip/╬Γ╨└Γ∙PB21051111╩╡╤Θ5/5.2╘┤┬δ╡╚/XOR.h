#include <stdio.h>
void XOR();