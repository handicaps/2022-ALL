#include<stdio.h>
#include"atof.h"
int main()
{
    char str[1000] = { 0 };
    int i = 0;
    for (i = 0;i < 1000;i++)
    {
        str[i] = getchar();
        if (str[i] == '\n')
            break;
    }
    atof(str);
    printf("\n");
    return 0;

}
