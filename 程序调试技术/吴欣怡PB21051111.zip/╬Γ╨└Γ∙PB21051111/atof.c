
#include "atof.h"
#include"math.h"
double atof(char* str)
{
    double sum = 0, fac = 10;
    int negflag = 0;
    if (*str)
    {
        if (*str == '-')
        {
            negflag = 1;
            str++;
        }
        while (*str != '.' && *str!='e' && *str != '\n')
        {
            sum = sum * 10 + (int)(*str) - 48;
            str++;
        }
        if (*str == '.') 
        {
            str++;
            while (*str && *str != 'e')
            {
                sum = sum + ((int)(*str) - 48) / fac;
                fac = fac * 10;
                str++;
            }
        }
        if (*str == 'e')
        {
            int flag = 0, num = 0, f = 0;
            double Exp = 0;
            str++;
            if (*str == '\n')
            {
                printf("Wrong input");
                return 1;
            }

            if (*str == '-')
            {
                flag = 1;
                str++;
            }
            while (*str != '.' && *str && *str != '\n')
            {
                num = num * 10 + (int)(*str) - 48;
                str++;
            }
            str++;
            while (*str && *str != '\n')
            {
                num = num + ((int)(*str) - 48) / f;
                f = f * 10;
                str++;
            }
            if (flag == 1)
                num = 0 - num;
            Exp = pow(10, num);
            sum = Exp * sum;
        }
        if (negflag == 1)
            sum = 0 - sum;
        printf("%.6lf", sum);
        return sum;
    }
    else
    {
        printf("warning:字符串为空");
        return 0;
    }
}
