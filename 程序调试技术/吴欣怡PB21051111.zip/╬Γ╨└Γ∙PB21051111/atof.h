#include <stdio.h>
double atof();

